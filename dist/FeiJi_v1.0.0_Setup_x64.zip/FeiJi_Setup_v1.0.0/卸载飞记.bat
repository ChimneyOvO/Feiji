@echo off
chcp 936 >nul
title ж�طɼ�
echo ����ж�طɼ�...
taskkill /F /IM FeiJi.exe >nul 2>&1

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$desk = [System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), '�ɼ�.lnk'); ^
   if (Test-Path $desk) { Remove-Item $desk -Force }; ^
   $sm = [System.IO.Path]::Combine([Environment]::GetFolderPath('StartMenu'), 'Programs\�ɼ�.lnk'); ^
   if (Test-Path $sm) { Remove-Item $sm -Force };"

set "TARGET_DIR=%LOCALAPPDATA%\FeiJi"
if exist "%TARGET_DIR%" rd /s /q "%TARGET_DIR%"

echo.
echo �ɼ��ѳɹ������ĵ�����ж�ء�
pause
